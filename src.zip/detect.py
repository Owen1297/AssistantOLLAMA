import keyboard
import os

# init
os.system("cls" if os.name == "nt" else "clear")
print("WAITING FOR ALT+A")
os.system("python3 C:/Users/laura/OneDrive/Documents/assistant/src/server.pyw")

# mainloop
run = True
while run:
    keyboard.wait("alt+a")
    print("Running Assistant")
    os.system("python3 C:/Users/laura/OneDrive/Documents/assistant/src/window.pyw")