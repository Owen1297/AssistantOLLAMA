import requests

class ai:
    def __init__(me,name,sysMSG="",streaming=False):
        me.modelName = name
        me.stream = streaming
        me.sys = sysMSG
    def prompt(me,prompt):
        dat = {
            "model": me.modelName,
            "prompt": f"{prompt} -- SYSTEM INSTRUCTIONS ARE AS FOLLOWS: {me.sys}",
            "stream": me.stream
        }
        return requests.post("http://localhost:11434/api/generate", json=dat).json()["response"]